MIND MATCH — ANDROID ILOVA LOYIHASI

Bu loyiha mavjud Mind Match HTML o‘yinini Android WebView ichida ishga tushiradi.

APK yaratish:
1. Kompyuterga Android Studio o‘rnating.
2. Android Studio’da Open ni bosing va MindMatch papkasini tanlang.
3. Gradle sync tugashini kuting. Android SDK Platform 35 so‘ralsa, SDK Manager orqali o‘rnating.
4. Test uchun telefonni USB orqali ulang yoki emulator oching va Run ▶ ni bosing.
5. APK olish: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK odatda app/build/outputs/apk/debug/app-debug.apk manzilida hosil bo‘ladi.

Google Play uchun:
- Release build va imzolangan Android App Bundle (.aab) tayyorlash kerak.
- Play Console hisobini ochish, listing, ikonka, skrinshotlar, maxfiylik siyosati va Data safety ma’lumotlarini tayyorlash kerak.
- Google Play talab qiladigan sinov va tekshiruvlardan o‘tish kerak.

Eslatma:
- Bu Android Studio loyiha manbasi; APK hali bu paket ichida tayyor holatda emas.
- Rekordlar va ochilgan bosqichlar hozircha shu qurilmaning ilova xotirasida saqlanadi; onlayn/global reyting emas.
- Google Play’ga chiqarishdan oldin haqiqiy qurilmalarda UI, audio, ekran o‘lchamlari va back tugmasi sinovdan o‘tkazilishi kerak.
